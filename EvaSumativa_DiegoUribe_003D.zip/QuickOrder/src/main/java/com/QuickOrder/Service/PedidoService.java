package com.QuickOrder.Service;

import com.QuickOrder.Model.Pedido;
import com.QuickOrder.Model.Estado;
import com.QuickOrder.Repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
/**
 * Este archivo hace de intermediario entre el controlador y el repositorio
 */
public class PedidoService {

    @Autowired
    private PedidoRepository repository;

    // Obtiene la lista total de pedidos registrados
    public List<Pedido> obtenerTodos() {
        return repository.findAll();
    }

    // Valida los datos obligatorios antes de registrar un pedido
    public Pedido registrarPedido(Pedido pedido) {
        // Validación de campos según requerimientos del caso
        if (pedido.getNombreCliente() == null || pedido.getNombreCliente().trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del cliente es obligatorio.");
        }
        if (pedido.getMontoTotal() == null || pedido.getMontoTotal() <= 0) {
            throw new IllegalArgumentException("El monto total debe ser un valor positivo.");
        }

        // Asignación automática de fecha del sistema
        pedido.setFechaPedido(LocalDate.now());

        // Si no se especifica el estado del pedido se asigna automaticamente
        if (pedido.getEstado() == null) {
            pedido.setEstado(Estado.PENDIENTE);
        }

        return repository.save(pedido);
    }

    //  Busca un pedido y en caso que no exista lanza una exepcion
    public Pedido buscarPorId(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("No existe el pedido con ID: " + id));
    }

    // Elimina un pedido y en caso de que no exista lanza error
    public void eliminarPedido(Long id) {
        if (!repository.delete(id)) {
            throw new RuntimeException("Error: El pedido solicitado no existe.");
        }
    }

    // Revisa toda la lista y devuelve solo los pedidos que tengan el estado que le pido
    public List<Pedido> filtrarPorEstado(Estado estado) {
        return repository.findAll().stream()
                .filter(p -> p.getEstado() == estado)
                .collect(Collectors.toList());
    }
}