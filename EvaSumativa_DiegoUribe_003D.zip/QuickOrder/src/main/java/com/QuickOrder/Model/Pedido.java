package com.QuickOrder.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
/**
 * Esta clase representa todos los datos de un pedido
 */
public class Pedido {
    private Long id;
    private String nombreCliente;
    private String descripcion;
    private Estado estado;
    private TipoPedido tipoPedido;
    private Double montoTotal;
    private LocalDate fechaPedido; // Se asigna automáticamente en el Service
}