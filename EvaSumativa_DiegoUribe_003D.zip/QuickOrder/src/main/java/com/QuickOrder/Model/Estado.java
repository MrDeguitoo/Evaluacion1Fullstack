package com.QuickOrder.Model;
/**
 * Los valores permitidos como estado del pedido
 */
public enum Estado {
    PENDIENTE,
    EN_PREPARACION,
    EN_CAMINO,
    ENTREGADO,
    CANCELADO
}