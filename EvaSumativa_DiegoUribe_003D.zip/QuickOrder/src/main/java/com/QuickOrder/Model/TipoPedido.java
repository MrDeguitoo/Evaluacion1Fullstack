package com.QuickOrder.Model;
/**
 * Los posibles tipos del pedido
 */
public enum TipoPedido {
    DELIVERY,
    RETIRO_EN_TIENDA,
    EXPRESS
}