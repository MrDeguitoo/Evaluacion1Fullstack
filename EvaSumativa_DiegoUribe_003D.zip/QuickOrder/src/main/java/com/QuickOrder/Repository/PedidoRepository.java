package com.QuickOrder.Repository;

import com.QuickOrder.Model.Pedido;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
//Esta clase hace que el programa se guarde en la memoria local
public class PedidoRepository {

    // Lista principal para almacenar los objetos Pedido
    private List<Pedido> listaPedidos = new ArrayList<>();

    // Con jakarta me dio error asi que hice asi el id autoincrementable
    private Long idActual = 1L;

    public List<Pedido> findAll() {
        return listaPedidos;
    }

    // Busca un pedido específico por su ID único
    public Optional<Pedido> findById(Long id) {
        return listaPedidos.stream()
                .filter(p -> p.getId().equals(id))
                .findFirst();
    }

    // Guarda un pedido nuevo o actualiza uno existente
    public Pedido save(Pedido pedido) {
        if (pedido.getId() == null) {
            pedido.setId(idActual++); // Asigna ID automático si es nuevo
        } else {
            this.delete(pedido.getId()); // Si existe para actualizar, lo borra de la lista
        }
        listaPedidos.add(pedido);
        return pedido;
    }

    // Elimina un pedido de la colección
    public boolean delete(Long id) {
        return listaPedidos.removeIf(p -> p.getId().equals(id));
    }
}