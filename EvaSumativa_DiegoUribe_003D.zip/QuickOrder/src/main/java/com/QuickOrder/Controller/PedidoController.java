package com.QuickOrder.Controller;

import com.QuickOrder.Model.Pedido;
import com.QuickOrder.Model.Estado;
import com.QuickOrder.Service.PedidoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pedidos")
// Clase que conecta el sistema con Postman
public class PedidoController {

    @Autowired
    private PedidoService service;

    @GetMapping
    public List<Pedido> listar() {
        return service.obtenerTodos(); // Retorna 200 OK
    }

    @PostMapping
    public ResponseEntity<?> guardar(@RequestBody Pedido pedido) {
        try {
            Pedido nuevo = service.registrarPedido(pedido);
            return new ResponseEntity<>(nuevo, HttpStatus.CREATED); // Retorna 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); // Error 400
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(@PathVariable Long id, @RequestBody Pedido datosNuevos) {
        try {
            // Buscam el pedido existente para modificarlo
            Pedido pedidoExistente = service.buscarPorId(id);

            // Actualiza los datos excepto el id y la fecha
            pedidoExistente.setNombreCliente(datosNuevos.getNombreCliente());
            pedidoExistente.setDescripcion(datosNuevos.getDescripcion());
            pedidoExistente.setEstado(datosNuevos.getEstado());
            pedidoExistente.setTipoPedido(datosNuevos.getTipoPedido());
            pedidoExistente.setMontoTotal(datosNuevos.getMontoTotal());

            // Guarda y valida los datos de nuevo
            Pedido actualizado = service.registrarPedido(pedidoExistente);
            return ResponseEntity.ok(actualizado); // Retorna 200 OK
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "Pedido no encontrado para actualizar")); // Error 404
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscar(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(service.buscarPorId(id)); // Retorna 200 OK
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", e.getMessage())); // Error 404 [cite: 51]
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        try {
            service.eliminarPedido(id);
            return ResponseEntity.noContent().build(); // Retorna 204 No Content [cite: 44, 47]
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/estado/{estado}")
    public List<Pedido> filtrar(@PathVariable Estado estado) {
        return service.filtrarPorEstado(estado); // Operación de procesamiento [cite: 45]
    }
}